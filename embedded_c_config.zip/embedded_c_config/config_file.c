void DIO_vSetPinDirection(PORTA, 2, HIGH)
{
	switch(Copy_u8PORT)
	{
		case PORT_A:
			if(copy_u8state==INPUT)
			{
				clearbit(PORTA_BASE->DDR, Copy_u8PinNumber);
				break;
			}
			else if(copy_u8state==OUTput)
			{
				setbit(PORTA_BASE->DDR, Copy_u8PinNumber);
				break;
			}
			else if(copy_u8state==IN_PULLUP)
			{
				clearbit(PORTA_BASE->DDR, Copy_u8PinNumber);
				setbit(PORTA_BASE->Port, Copy_u8PinNumber);
				break;
			}

		case PORT_B:
			if(copy_u8state==IN)
			{
				clearbit(PORTB_BASE->DDR, Copy_u8PinNumber);
				break;
			}
			else if(copy_u8state==OUT)
			{
				setbit(PORTB_BASE->DDR, Copy_u8PinNumber);
				break;
			}
			else if(copy_u8state==IN_PULLUP)
			{
				clearbit(PORTB_BASE->DDR, Copy_u8PinNumber);
				setbit(PORTB_BASE->Port, Copy_u8PinNumber);
				break;
			}

		case PORT_C:
			if(copy_u8state==IN)
			{
				clearbit(PORTC_BASE->DDR, Copy_u8PinNumber);
				break;
			}
			else if(copy_u8state==OUT)
			{
				setbit(PORTC_BASE->DDR, Copy_u8PinNumber);
				break;
			}
			else if(copy_u8state==IN_PULLUP)
			{
				clearbit(PORTC_BASE->DDR, Copy_u8PinNumber);
				setbit(PORTC_BASE->Port, Copy_u8PinNumber);
				break;
			}

		case PORT_D:
			if(copy_u8state==IN)
			{
				clearbit(PORTD_BASE->DDR, Copy_u8PinNumber);
				break;
			}
			else if(copy_u8state==OUT)
			{
				setbit(PORTD_BASE->DDR, Copy_u8PinNumber);
				break;
			}
			else if(copy_u8state==IN_PULLUP)
			{
				clearbit(PORTD_BASE->DDR, Copy_u8PinNumber);
				setbit(PORTD_BASE->Port, Copy_u8PinNumber);
				break;
			}

	}
}
void DIO_vWritePin(PORTB), 3, HIGH)
{
	switch(Copy_u8PORT)
	{
		case PORT_A:
			if(Copy_u8value==LOW)
			{
				clearbit(PORTA_BASE->Port, Copy_u8PinNumber);
				break;
			}
			else if(Copy_u8value==HIGH)
			{
				setbit(PORTA_BASE->Port, Copy_u8PinNumber);
				break;
			}
			else
			{
				//Error
				break;
			}

		case PORT_B:
			if(Copy_u8value==LOW)
			{
				clearbit(PORTB_BASE->Port, Copy_u8PinNumber);
				break;
			}
			else if(Copy_u8value==HIGH)
			{
				setbit(PORTB_BASE->Port, Copy_u8PinNumber);
				break;
			}
			else
			{
				//Error
				break;
			}

		case PORT_C:
			if(Copy_u8value==LOW)
			{
				clearbit(PORTC_BASE->Port, Copy_u8PinNumber);
				break;
			}
			else if(Copy_u8value==HIGH)
			{
				setbit(PORTC_BASE->Port, Copy_u8PinNumber);
				break;
			}
			else
			{
				//Error
				break;
			}

		case PORT_D:
			if(Copy_u8value==LOW)
			{
				clearbit(PORTD_BASE->Port, Copy_u8PinNumber);
				break;
			}
			else if(Copy_u8value==HIGH)
			{
				setbit(PORTD_BASE->Port, Copy_u8PinNumber);
				break;
			}
			else
			{
				//Error
				break;
			}

	}
}